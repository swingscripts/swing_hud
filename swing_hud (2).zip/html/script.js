const HUD = {
  config: {},
  playerId: 0,
  isVisible: false
};

window.addEventListener("message", (event) => {
  const { type, data, state } = event.data;

  switch (type) {
    case "init":
      HUD.config = data.config;
      HUD.playerId = data.playerId;
      break;

    case "toggle":
      HUD.isVisible = state;
      const hudElement = document.getElementById("hud");
      if (state) {
        hudElement.classList.remove("opacity-0");
        hudElement.classList.add("opacity-100");
      } else {
        hudElement.classList.remove("opacity-100");
        hudElement.classList.add("opacity-0");
      }
      break;

    case "status":
      updateStatus(data);
      break;

    case "weapon":
      updateWeapon(data);
      break;

    case "location":
      updateLocation(data);
      break;

    case "voice":
      updateVoice(data);
      break;

    case "info":
      updateInfo(data);
      break;
  }
});

function updateStatus(data) {
  const healthBar = document.getElementById("health-bar");
  const healthText = document.getElementById("health-text");
  const armorBar = document.getElementById("armor-bar");
  const armorText = document.getElementById("armor-text");
  const hungerBar = document.getElementById("hunger-bar");
  const hungerText = document.getElementById("hunger-text");
  const thirstBar = document.getElementById("thirst-bar");
  const thirstText = document.getElementById("thirst-text");
  const staminaBar = document.getElementById("stamina-bar");
  const oxygenBar = document.getElementById("oxygen-bar");

  const healthPercent = Math.max(0, Math.min(100, data.health));
  healthBar.style.width = `${healthPercent}%`;
  healthText.textContent = Math.round(healthPercent);

  const armorPercent = Math.max(0, Math.min(100, data.armor));
  armorBar.style.width = `${armorPercent}%`;
  armorText.textContent = Math.round(armorPercent);

  const hungerPercent = Math.max(0, Math.min(100, data.hunger));
  hungerBar.style.width = `${hungerPercent}%`;
  hungerText.textContent = Math.round(hungerPercent);

  const thirstPercent = Math.max(0, Math.min(100, data.thirst));
  thirstBar.style.width = `${thirstPercent}%`;
  thirstText.textContent = Math.round(thirstPercent);

  const staminaPercent = Math.max(0, Math.min(100, data.stamina));
  staminaBar.style.width = `${staminaPercent}%`;

  const oxygenPercent = Math.max(0, Math.min(100, data.oxygen));
  oxygenBar.style.width = `${oxygenPercent}%`;
}

function updateWeapon(data) {
  const weaponContainer = document.getElementById("weapon-container");
  const weaponName = document.getElementById("weapon-name");
  const weaponAmmo = document.getElementById("weapon-ammo");

  if (data.active) {
    weaponContainer.classList.remove("hidden");
    weaponName.textContent = data.name || "Weapon";
    weaponAmmo.textContent = `${data.ammo} / ${data.maxAmmo}`;
  } else {
    weaponContainer.classList.add("hidden");
  }
}

function updateLocation(data) {
  const streetName = document.getElementById("street-name");
  const areaName = document.getElementById("area-name");

  streetName.textContent = data.street || "Unknown Street";
  areaName.textContent = data.area || "Unknown Area";
}

function updateVoice(data) {
  const voiceContainer = document.getElementById("voice-container");
  const voiceIcon = document.getElementById("voice-icon");

  if (data.talking) {
    voiceContainer.classList