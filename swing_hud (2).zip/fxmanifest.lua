fx_version "cerulean"
game "gta5"

author "SwisserAI"
description "Generated with SwisserAI - https://ai.swisser.dev"
version "1.0.0"

shared_script "@es_extended/imports.lua"

client_scripts {
    "client/main.lua",
    "client/status.lua",
    "client/weapon.lua",
    "client/money.lua",
    "client/location.lua"
}

server_script "server/main.lua"

ui_page "html/index.html"

files {
    "html/index.html",
    "html/style.css",
    "html/script.js"
}

dependencies {
    "es_extended",
    "esx_status"
}