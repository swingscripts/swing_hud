Config = {}

Config.Hud = {
    position = "bottom-right",
    showMinimap = true,
    showPlayerId = true,
    showServerLogo = true,
    showJob = true,
    showMoney = true,
    showWeapon = true,
    showStatus = true,
    showLocation = true,
    showVoice = true
}

Config.Colors = {
    primary = "#00d4ff",
    secondary = "#ff6b00",
    health = "#ff4757",
    armor = "#3742fa",
    hunger = "#ffa502",
    thirst = "#1e90ff",
    stamina = "#2ed573",
    oxygen = "#00d2d3",
    background = "rgba(15, 15, 20, 0.85)",
    text = "#ffffff"
}

Config.Status = {
    maxValue = 100,
    tickRate = 500
}

Config.Weapon = {
    showAmmo = true,
    showIcon = true
}

Config.Location = {
    showStreet = true,
    showArea = true
}