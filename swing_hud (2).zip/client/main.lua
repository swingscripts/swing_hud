local ESX = exports["es_extended"]:getSharedObject()
local HUD = {}
HUD.Data = {}
HUD.Ready = false

HUD.Data.Health = 100
HUD.Data.Armor = 0
HUD.Data.Hunger = 100
HUD.Data.Thirst = 100
HUD.Data.Stamina = 100
HUD.Data.Oxygen = 100
HUD.Data.Money = { cash = 0, bank = 0 }
HUD.Data.Job = { label = "Unemployed", gradeLabel = "", onDuty = false }
HUD.Data.Weapon = { active = false, name = "", ammo = 0, maxAmmo = 0 }
HUD.Data.Location = { street = "", area = "" }
HUD.Data.Voice = { talking = false, radio = false, range = 1 }
HUD.Data.PlayerId = 0
HUD.Data.OnlinePlayers = 0

CreateThread(function()
    while not ESX do
        ESX = exports["es_extended"]:getSharedObject()
        Wait(100)
    end

    while not ESX.PlayerLoaded do
        Wait(100)
    end

    HUD.Ready = true
    HUD:Initialize()
end)

function HUD:Initialize()
    local playerId = GetPlayerServerId(PlayerId())
    self.Data.PlayerId = playerId

    TriggerServerEvent("jghud:server:requestInitialData")

    self:StartThreads()
    self:Toggle(true)

    SendNUIMessage({
        type = "init",
        data = {
            config = Config.Hud,
            playerId = playerId
        }
    })
end

function HUD:StartThreads()
    self:StatusThread()
    self:WeaponThread()
    self:MoneyThread()
    self:LocationThread()
    self:VoiceThread()
    self:FastUpdateThread()
end

function HUD:Toggle(state)
    SendNUIMessage({
        type = "toggle",
        state = state
    })
end

function HUD:StatusThread()
    CreateThread(function()
        while not HUD.Ready do Wait(100) end

        while true do
            local ped = PlayerPedId()

            if ESX.PlayerLoaded then
                local health = GetEntityHealth(ped)
                local armor = GetPedArmour(ped)
                local stamina = 100 - math.floor(GetPlayerSprintStaminaRemaining(PlayerId()))
                local oxygen = 100

                if IsPedSwimmingUnderWater(ped) then
                    oxygen = math.floor(GetPlayerUnderwaterTimeRemaining(PlayerId()) * 10)
                end

                HUD.Data.Health = health
                HUD.Data.Armor = armor
                HUD.Data.Stamina = stamina
                HUD.Data.Oxygen = oxygen

                SendNUIMessage({
                    type = "status",
                    data = {
                        health = HUD.Data.Health - 100,
                        armor = HUD.Data.Armor,
                        stamina = HUD.Data.Stamina,
                        oxygen = HUD.Data.Oxygen,
                        hunger = HUD.Data.Hunger,
                        thirst = HUD.Data.Thirst
                    }
                })
            end

            Wait(250)
        end
    end)
end

function HUD:WeaponThread()
    CreateThread(function()
        while not HUD.Ready do Wait(100) end

        while true do
            local ped = PlayerPedId()
            local weapon = GetSelectedPedWeapon(ped)

            if weapon ~= 0 then
                local _, ammo = GetAmmoInClip(ped, weapon)
                local maxAmmo = GetWeaponClipSize(weapon)
                local name = HUD:GetWeaponName(weapon)

                HUD.Data.Weapon = {
                    active = true,
                    name = name,
                    ammo = ammo,
                    maxAmmo = maxAmmo
                }
            else
                HUD.Data.Weapon.active = false
            end

            SendNUIMessage({
                type = "weapon",
                data = HUD.Data.Weapon
            })

            Wait(500)
        end
    end)
end

function HUD:GetWeaponName(weaponHash)
    local weaponNames = {
        [0x1B06D571] = "Pistol",
        [0xBFE256D4] = "Pistol MK2",
        [0x22D8FF39] = "Combat Pistol",
        [0xD205520E] = "Heavy Pistol",
        [0xCB96392F] = "Revolver",
        [0x97EA7B76] = "SMG",
        [0x2C6761CC] = "Micro SMG",
        [0x7F2298DF] = "Assault SMG",
        [0x13532244] = "Carbine Rifle",
        [0x611B019C] = "Advanced Rifle",
        [0xC0A3098D] = "Bullpup Rifle",
        [0xD4CBFC1C] = "Special Carbine",
        [0xA3B47C75] = "Pump Shotgun",
        [0xE284C527] = "Sawed-Off Shotgun",
        [0xFDBAB292] = "Combat Shotgun",
        [0xA89CB99E] = "Sniper Rifle",
        [0x9D1F17E6] = "Heavy Sniper",
        [0xC734385A] = "Grenade Launcher",
        [0x4DD2DC56] = "RPG",
        [0x42BF8A85] = "Stun Gun",
        [0x92A27487] = "Knife",
        [0x0C3F8401] = "Bat",
        [0x958A4A8F] = "Crowbar"
    }

    return weaponNames[weaponHash] or "Unknown"
end

function HUD:MoneyThread()
    CreateThread(function()
        while not HUD.Ready do Wait(100) end

        while true do
            TriggerServerEvent("jghud:server:updateMoney")
            Wait(5000)
        end
    end)
end

function HUD:LocationThread()
    CreateThread(function()
        while not HUD.Ready do Wait(100) end

        while true do
            local ped = PlayerPedId()
            local coords = GetEntityCoords(ped)
            local street = GetStreetNameFromHashKey(GetStreetNameAtCoord(coords.x, coords.y, coords.z))
            local zone = GetLabelText(GetNameOfZone(coords.x, coords.y, coords.z))

            HUD.Data.Location = {
                street = street or "Unknown",
                area = zone or "Unknown"
            }

            SendNUIMessage({
                type = "location",
                data = HUD.Data.Location
            })

            Wait(1000)
        end
    end)
end

function HUD:VoiceThread()
    CreateThread(function()
        while not HUD.Ready do Wait(100) end

        while true do
            local talking = NetworkIsPlayerTalking(PlayerId())

            HUD.Data.Voice.talking = talking

            SendNUIMessage({
                type = "voice",
                data = HUD.Data.Voice
            })

            Wait(100)
        end
    end)
end

function HUD:FastUpdateThread()
    CreateThread(function()
        while not HUD.Ready do Wait(100) end

        while true do
            local serverId = GetPlayerServerId(PlayerId())
            local onlinePlayers = GlobalState["playerCount"] or 0

            SendNUIMessage({
                type = "info",
                data = {
                    playerId = serverId,
                    onlinePlayers = onlinePlayers,
                    job = HUD.Data.Job,
                    money = HUD.Data.Money
                }
            })

            Wait(500)
        end
    end)
end

RegisterNetEvent("jghud:client:initialData", function(data)
    if data.money then
        HUD.Data.Money = data.money
    end
    if data.job then
        HUD.Data.Job = data.job
    end
end)

RegisterNetEvent("jghud:client:updateMoney", function(money)
    HUD.Data.Money = money
end)

RegisterNetEvent("jghud:client:updateJob", function(job)
    HUD.Data.Job = job
end)

RegisterNetEvent("jghud:client:playerLoaded", function(data)
    HUD.Data.PlayerId = GetPlayerServerId(PlayerId())
end)

AddEventHandler("esx_status:onTick", function(data)
    for i = 1, #data do
        if data[i].name == "hunger" then
            HUD.Data.Hunger = math.floor(data[i].percent)
        elseif data[i].name == "thirst" then
            HUD.Data.Thirst = math.floor(data[i].percent)
        end
    end
end)

RegisterCommand("togglehud", function()
    HUD:Toggle(not HUD.Ready)
end, false)