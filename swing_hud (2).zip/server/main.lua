local ESX = exports["es_extended"]:getSharedObject()

RegisterNetEvent("jghud:server:updateMoney", function(data)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return end

    local money = {
        cash = xPlayer.getMoney(),
        bank = xPlayer.getAccount("bank").money
    }

    TriggerClientEvent("jghud:client:updateMoney", src, money)
end)

RegisterNetEvent("jghud:server:updateJob", function(data)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return end

    local job = {
        name = xPlayer.job.name,
        label = xPlayer.job.label,
        grade = xPlayer.job.grade,
        gradeLabel = xPlayer.job.grade_label,
        onDuty = xPlayer.job.grade > 0
    }

    TriggerClientEvent("jghud:client:updateJob", src, job)
end)

RegisterNetEvent("jghud:server:requestInitialData", function()
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return end

    local money = {
        cash = xPlayer.getMoney(),
        bank = xPlayer.getAccount("bank").money
    }

    local job = {
        name = xPlayer.job.name,
        label = xPlayer.job.label,
        grade = xPlayer.job.grade,
        gradeLabel = xPlayer.job.grade_label,
        onDuty = xPlayer.job.grade > 0
    }

    TriggerClientEvent("jghud:client:initialData", src, {
        money = money,
        job = job
    })
end)

AddEventHandler("esx:playerLoaded", function(playerId, xPlayer)
    TriggerClientEvent("jghud:client:playerLoaded", playerId, {
        identifier = xPlayer.identifier,
        name = xPlayer.getName()
    })
end)

AddEventHandler("esx:setJob", function(playerId, job)
    TriggerClientEvent("jghud:client:updateJob", playerId, {
        name = job.name,
        label = job.label,
        grade = job.grade,
        gradeLabel = job.grade_label,
        onDuty = job.grade > 0
    })
end)